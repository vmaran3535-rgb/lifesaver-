LifeSaver AI – Enhanced Emergency Safety Hub

HOW TO RUN
1. Extract the ZIP file.
2. Open the LifeSaver_AI_Enhanced folder.
3. Open index.html in a modern browser.
4. Allow location permission if you want to use GPS/weather. Internet is required for external map, weather, fonts and 3D library features.

NEW FEATURES
- Flood Safety Mode: Tamil Nadu monsoon preparedness guidance and official IMD/NDMA links. It is not a live warning feed.
- SOS Family Alert: prepares an SMS for you to review and send. It does not send silently or guarantee delivery.
- Nearby Help Finder: opens an OpenStreetMap search for hospitals, clinics, pharmacies, fire stations or police stations near an entered area or available coordinates. Verify results before travelling.
- Tamil/English voice: use the existing Voice Assistant language selection and browser speech support.
- Smart Family Safety: use the existing Family Safety Network to add family members and record local check-ins.

IMPORTANT LIMITATIONS
This is a front-end prototype, not a certified emergency service. The SOS feature depends on the device's SMS app and mobile service. Nearby map search results are not verified emergency referrals. Family records remain in this browser and are not shared live. Flood guidance is educational and does not provide real-time alerts. For urgent emergencies in India call 112 and follow official authorities.
